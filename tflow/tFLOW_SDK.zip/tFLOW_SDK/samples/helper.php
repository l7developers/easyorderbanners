<?php

if(PHP_SAPI !== 'cli')
{
    throw new \Exception('This program intended to be run from command line and not within a web server.');
}

require_once __DIR__ . '/../vendor/autoload.php';

//
// OAuth2 Authentication credentials
//
$clientId = 'NQSXf3rE9eZT0kbS';
$clientSecret = '1A8BdpgQwAwnQtpp6GWWEtnaZ5jh4aeg';

//
// Base URI
//
$baseUri = 'http://tracker.local';


