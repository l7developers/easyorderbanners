<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

try
{
    $userEmail = 'team@tucanna.com';  // this user exists by default in each instance
    $companyName = 'Anonymous Uploading'; // this company exists by default in each instance
    $productName = 'Passthrough';

    $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

    printf('Creating a new order' . PHP_EOL);

    $orderParams = [
        //'name' => 'OrderFromApi',  // this is not mandatory, if not specified, the system will generate a name automatically
        'description' => 'This order has been created via API',
        'ship_date' => (new \DateTime())->format(\DateTime::ISO8601),
        'client_id' => 0,                                            // will be replaced with actual value
        'product_id' => 0,
        'assignments' => [],
        'tflows' => [],
        'props' => [
            'print_width' => 10,
            'print_height' => 10,
        ],
    ];

    $users = $apiClient->listUsers($userEmail);
    if(empty($users))
        throw new Exception('Can not find user with email "' . $userEmail . '"');

    $companies = $apiClient->listClients($companyName);
    if(empty($companies))
        throw new Exception('Can not find company "' . $companyName . '"');

    $products = $apiClient->listProducts($productName);
    if(empty($products))
        throw new Exception('Cannot find product "' . $productName . '"');

    $tflows = $apiClient->listTflows();

    $orderParams['client_id'] = $companies[0]['id'];

    $orderParams['product_id'] = $products[0]['id'];

    $orderParams['assignments']['instance_user_ids'] = [$users[0]['id']];
    $orderParams['assignments']['non_instance_user_ids'] = [];

    $orderParams['tflows'] = [];
    foreach($tflows as $tf)
    {
        $orderParams['tflows'][] = ['id' => $tf['id']];
    }

    $orderData = $apiClient->createOrder($orderParams);

    printf('Created order #%d with name "%s" and the following description: ' . PHP_EOL . PHP_EOL . '%s' . PHP_EOL, $orderData['id'], $orderData['name'], $orderData['description']);

    $jobParams = [
        'name' => 'JobFromApi',
        'order_id' => $orderData['id'],
        'priority' => 0,
        'product_id' => $orderParams['product_id'],
        'attach_proofs' => false,
        'ship_date' => (new \DateTime())->format(\DateTime::ISO8601),
        'assignments' => $orderParams['assignments'],
        'tflows' => $orderParams['tflows'],
        'props' => [],
    ];

    $jobData = $apiClient->createJob($jobParams);

    printf('Created job #%d with name "%s"' . PHP_EOL, $jobData['id'], $jobData['name']);

    $apiClient->uploadArtwork($jobData['id'], 'c:\temp\!samples\20hoxfinal2.pdf');

    printf('Created a new revision for job #%d' . PHP_EOL, $jobData['id']);
}
catch(\Exception $ex)
{
    echo $ex;
}
