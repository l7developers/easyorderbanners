<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

try
{
    $newCompanyName = 'ApiCompany created at ' . date('Y-m-d H:i:s') ;

    $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

    $tflows = $apiClient->listTflows();

    $companyParams = [
        'name' => $newCompanyName,
        'tflows' => [],
    ];

    foreach($tflows as $tf)
    {
        $companyParams['tflows'][] = ['id' => $tf['id']];
    }

    $companyData = $apiClient->createCompany($companyParams);

    echo 'A company with name "' . $companyData['name'] . '" successfully created with id #' . $companyData['id'] . PHP_EOL;
}
catch (\Exception $ex)
{
    echo $ex;
}
