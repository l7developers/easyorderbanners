<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

try
{
    $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

    $webHookParams = [
        'name' => 'job.create',
        'url' => 'http://some.example-url.com?param1=true&param2=false',
        'security_key' => 'abcdef0123456789',
    ];

    $webhookData = $apiClient->createWebhook($webHookParams);

    echo 'A webhook has been created successfully' . PHP_EOL
        . 'name: ' . $webhookData['name'] . PHP_EOL
        . 'failed_attempts: ' . $webhookData['failed_attempts'] . PHP_EOL
        . 'url: ' . $webhookData['url'] . PHP_EOL
        . 'security_key: ' . $webhookData['security_key'] . PHP_EOL;
}
catch(\Exception $ex)
{
    echo $ex;
}
