<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

try
{
    $jobId = 1;

    printf('Getting allowed transitions for job #%d' . PHP_EOL, $jobId);

    $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

    $jobData = $apiClient->getAllowedTransitions($jobId);

    printf('Job #%d has following transitions awailable:' . PHP_EOL, $jobId);

    foreach($jobData as $t)
    {
       printf('%s' . PHP_EOL, $t);
    }
}
catch(\Exception $ex)
{
    echo $ex;
}
