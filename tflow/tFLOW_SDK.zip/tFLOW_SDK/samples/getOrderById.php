<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

try
{
    $orderId = 147;

    printf('Getting info about order #%d' . PHP_EOL, $orderId);

    $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

    $orderData = $apiClient->getOrder($orderId);

    printf('Order #%d has name "%s" and the following description: ' . PHP_EOL . PHP_EOL . '%s' . PHP_EOL, $orderId, $orderData['name'], $orderData['description']);
}
catch(\GuzzleHttp\Exception\ClientException $ex)
{
    $body = $ex->getResponse()->getBody();

    $bodyText = $body->read(0x10000);
    echo $bodyText;
}
catch(\Exception $ex)
{
    echo $ex;
}
