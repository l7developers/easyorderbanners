<?php

require_once __DIR__ . '/helper.php';

use Tucanna\ApprovalSdk\Client as ApiClient;

$runId = uniqid('_', true);

$time = 'XXX'; //time();

try
{
   $tflowId = 'TFLOW_XXX_591c5511b58c30.26293145'; // uniqid('TFLOW_' . $time . '_', true);
   $tflowName = 'TFLOW_' . $time;

   $numberOfQueues = rand(5, 20);

   $queuesInfo = [];
   for($i = 0; $i < $numberOfQueues; $i++)
   {
      $queuesInfo[] = [
         'id' => 'QUEUE_XXX_' . $i, // uniqid('QUEUE_' . $time . '_', true),
         'name' => 'QUEUE_' . $i,
      ];
   }

   $apiClient = new ApiClient($baseUri, $clientId, $clientSecret);

   $result = $apiClient->checkReady($tflowId, $tflowName, $queuesInfo);

   file_put_contents('result' . $runId, json_encode($result, JSON_PRETTY_PRINT));
}
catch (\Exception $ex)
{
    file_put_contents('error' . $runId, $ex->getMessage());
}
