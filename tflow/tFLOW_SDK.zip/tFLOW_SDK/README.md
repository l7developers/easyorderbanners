# Installation

This package is intended to be used with [Composer](http://getcomposer.org),
a de-facto standard package manager for PHP.

Once you have installed Composer in your system, run this:
```
$ php composer.phar install
```

It will install all dependencies those need to run provided samples.
After that, edit `samples/helper.php` and change `clientId`, `clientSecret`,
and `baseUri` variables appropriately.

# Usage

There are a basic API Client implementation which demonstrates one of the
possible approaches, and two PHP files:
* `samples/getOrderById.php` - demonstrates the simplest possible operation -
how to get information about an order by its ID.
* `samples/createOrder.php` - demonstrates a real-life task - how to create
an order, create a job inside that order, and upload an artwork into that job.

Each of these files can be run in console like this:
```
$ php samples/getOrderById.php
```


